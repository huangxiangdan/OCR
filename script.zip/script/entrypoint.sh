#!/bin/bash
RAILS_ENV=docker rails s
