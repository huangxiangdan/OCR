sudo apt-get update
sudo apt-get install -y libqt4-dev libqtwebkit-dev xvfb --no-install-recommends
sudo apt-get install -y nodejs mysql-client locales --no-install-recommends

cd /usr/local/share
sudo wget https://bitbucket.org/ariya/phantomjs/downloads/phantomjs-1.9.7-linux-x86_64.tar.bz2
sudo tar xjf phantomjs-1.9.7-linux-x86_64.tar.bz2
sudo ln -s /usr/local/share/phantomjs-1.9.7-linux-x86_64/bin/phantomjs /usr/local/share/phantomjs
sudo ln -s /usr/local/share/phantomjs-1.9.7-linux-x86_64/bin/phantomjs /usr/local/bin/phantomjs
sudo ln -s /usr/local/share/phantomjs-1.9.7-linux-x86_64/bin/phantomjs /usr/bin/phantomjs

cd ~
git clone git@github.com:classbox/spiderman.git
cd spiderman
mkdir ~/ocr
cd ~/ocr && tar xvzf ~/spiderman/script/Dockerfiles/spiderman_base/dependency/ImageMagick.tar.gz && cd ImageMagick && ./configure && sudo make && sudo make install
cd ~/ocr && tar xvzf ~/spiderman/script/Dockerfiles/spiderman_base/dependency/leptonica.tar.gz && cd leptonica && ./configure && sudo make && sudo make install
cd ~/ocr && tar xvzf ~/spiderman/script/Dockerfiles/spiderman_base/dependency/tesseract-ocr.tar.gz && cd tesseract-ocr && ./configure && sudo make && sudo make install
sudo cp ~/ocr/tesseract-ocr/tessdata/eng.traineddata /usr/local/share/tessdata/

echo 2.0.0-p481 > /var/www/spiderman/shared/.ruby-version
