#!/bin/bash
rake db:create
rake db:schema:load
rake db:seed
# rake what_can_do:seed
